package com.example.finalproject;

public interface SelectListenerForStudents {
    void onItemClicked(TraineeInSection traineeInSection);

}
