package com.example.finalproject;

public interface SelectListener {
    void onItemClicked(Section section);

}
